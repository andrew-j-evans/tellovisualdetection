# Change Log
All notable changes to this project will be documented in this file.

## tellovisualdetection

Editor: A. Evans

## [Unreleased]

### [0.0.0] -2023-05-01
### Added
- Tello visual detection software with two different colors
- Tello movement commands for rotating towards the target and calibrating distance